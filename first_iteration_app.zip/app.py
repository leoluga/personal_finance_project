from flask import Flask, render_template, request, redirect, url_for, jsonify
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from datetime import datetime
from models import Base, User, Category, SubCategory, MainTable, PaymentMethod 

app = Flask(__name__)

engine = create_engine('sqlite:///personal_finance.db')
Base.metadata.bind = engine
DBSession = sessionmaker(bind=engine)
session = DBSession()

@app.route('/')
def index():
    records = session.query(MainTable).all()
    print(records)
    return render_template('index.html', records=records)

@app.route('/add', methods=['GET', 'POST'])
def add_record():
    if request.method == 'POST':
        user_id = request.form['user_id']
        category_id = request.form['category_id']
        sub_category_id = request.form['sub_category_id']
        payment_method_id = request.form['payment_method_id']
        year = request.form['year']
        month = request.form['month']
        day = request.form['day']
        value = request.form['value']
        description = request.form['description']
        date_added = datetime.now().date()

        new_record = MainTable(
            user_id=user_id,
            category_id=category_id,
            sub_category_id=sub_category_id,
            payment_method_id = payment_method_id,
            year=year,
            month=month,
            day=day,
            date_added=date_added,
            value=value,
            description=description
        )
        session.add(new_record)
        session.commit()
        return redirect(url_for('index'))
    users = session.query(User).all()
    categories = session.query(Category).all()
    sub_categories = session.query(SubCategory).all()
    return render_template('add_record.html', users=users, categories=categories, sub_categories=sub_categories)

@app.route('/get_payment_methods/<int:user_id>', methods=['GET'])
def get_payment_methods(user_id):
    payment_methods = session.query(PaymentMethod).filter_by(user_id=user_id).all()
    methods_list = [{'payment_method_id': pm.payment_method_id, 'method_name': pm.method_name} for pm in payment_methods]
    return jsonify({'payment_methods': methods_list})

# Edit a Record
@app.route('/edit/<int:record_id>', methods=['GET', 'POST'])
def edit_record(record_id):
    record = session.query(MainTable).filter_by(record_id=record_id).one()
    if request.method == 'POST':
        record.user_id = request.form['user_id']
        record.category_id = request.form['category_id']
        record.sub_category_id = request.form['sub_category_id']
        record.payment_method_id = request.form['payment_method_id'] 
        record.year = request.form['year']
        record.month = request.form['month']
        record.day = request.form['day']
        record.value = request.form['value']
        record.description = request.form['description']  
        session.commit()
        return redirect(url_for('index'))

    users = session.query(User).all()
    categories = session.query(Category).all()
    sub_categories = session.query(SubCategory).all()
    payment_methods = session.query(PaymentMethod).filter_by(user_id=record.user_id).all()
    return render_template('edit_record.html', record=record, users=users, categories=categories, sub_categories=sub_categories, payment_methods=payment_methods)

@app.route('/delete/<int:record_id>', methods=['GET', 'POST'])
def delete_record(record_id):
    record = session.query(MainTable).filter_by(record_id=record_id).one()
    session.delete(record)
    session.commit()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, port=5050)
