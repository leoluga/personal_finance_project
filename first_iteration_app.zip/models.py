from sqlalchemy import create_engine, Column, Integer, String, ForeignKey, Date, Float
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

# Define the Base class for our models
Base = declarative_base()

# User Table (user_id will come from this)
class User(Base):
    __tablename__ = 'user_table'
    user_id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String, nullable=False)

    # Relationship to the main table
    main_records = relationship('MainTable', back_populates='user')
    
    # Relationship to payment methods
    payment_methods = relationship('PaymentMethod', back_populates='user')

# Payment Method Table (linked to User)
class PaymentMethod(Base):
    __tablename__ = 'payment_method'
    payment_method_id = Column(Integer, primary_key=True, autoincrement=True)
    method_name = Column(String, nullable=False)
    user_id = Column(Integer, ForeignKey('user_table.user_id'), nullable=False)

    # Relationship to User and MainTable
    user = relationship('User', back_populates='payment_methods')
    main_records = relationship('MainTable', back_populates='payment_method')

# Category Table (Defines available categories)
class Category(Base):
    __tablename__ = 'category_table'
    category_id = Column(Integer, primary_key=True, autoincrement=True)
    category_name = Column(String, nullable=False, unique=True)

    # Relationship to the subcategory table
    sub_categories = relationship('SubCategory', back_populates='category')

# Subcategory Table (Linked to the Category Table)
class SubCategory(Base):
    __tablename__ = 'sub_category'
    sub_category_id = Column(Integer, primary_key=True, autoincrement=True)
    sub_category_name = Column(String, nullable=False)
    category_id = Column(Integer, ForeignKey('category_table.category_id'))

    # Relationship to the Category Table and Main Table
    category = relationship('Category', back_populates='sub_categories')
    main_records = relationship('MainTable', back_populates='sub_category')

# Main Table (Contains user data, linked to category and subcategory)
class MainTable(Base):
    __tablename__ = 'main_table'
    record_id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('user_table.user_id'), nullable=False)
    category_id = Column(Integer, ForeignKey('category_table.category_id'), nullable=False)
    sub_category_id = Column(Integer, ForeignKey('sub_category.sub_category_id'), nullable=False)
    payment_method_id = Column(Integer, ForeignKey('payment_method.payment_method_id'), nullable=False)
    year = Column(Integer, nullable=False)
    month = Column(Integer, nullable=False)
    day = Column(Integer)
    date_added = Column(Date, nullable=False)
    value = Column(Float, nullable=False)
    description = Column(String)

    # Relationships to other tables
    user = relationship('User', back_populates='main_records')
    category = relationship('Category')
    sub_category = relationship('SubCategory', back_populates='main_records')
    payment_method = relationship('PaymentMethod', back_populates='main_records')

# Function to create the SQLite database and tables
def create_database(db_name='personal_finance.db'):
    # Create an engine
    engine = create_engine(f'sqlite:///{db_name}', echo=True)

    # Create all tables defined above
    Base.metadata.create_all(engine)

    # Return the session for data insertion
    Session = sessionmaker(bind=engine)
    return Session()

# Create the database
if __name__ == '__main__':
    session = create_database()

    # Example of adding initial data
    leo_user = User(username='Leonardo')
    session.add(leo_user)
    
    melina_user = User(username='Melina')
    session.add(melina_user)
    
    # Adding categories and subcategories
    expense_category = Category(category_name='Expense')
    session.add(expense_category)

    groceries_sub_category = SubCategory(sub_category_name='Groceries', category=expense_category)
    session.add(groceries_sub_category)
    
     # Adding a payment method
    payment_method = PaymentMethod(method_name="Leo's Credit Card", user=leo_user)
    session.add(payment_method)
    payment_method = PaymentMethod(method_name="Lina Credit Card", user=melina_user)
    session.add(payment_method) 
    
    # Commit the changes
    session.commit()

    print("Database and initial data created successfully.")
